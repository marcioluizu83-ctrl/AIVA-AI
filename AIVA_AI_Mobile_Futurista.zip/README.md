# AIVA AI — Mobile (Fase 1 Plus)

Versão mobile otimizada (tema escuro) para deploy na Vercel.

## Instruções rápidas
1. Faça o download do arquivo ZIP.
2. No GitHub, vá ao repositório `AIVA-AI` e clique em Add file → Upload files.
3. Envie todo o conteúdo do ZIP (ou faça unzip e envie os arquivos).
4. Volte à Vercel e importe o repositório; faça deploy com Framework: Vite.

## Recursos
- Despertador via Notification API
- Reconhecimento de voz no navegador (SpeechRecognition)
- Indicadores básicos: BTC (CoinDesk) e USD-BRL (exchangerate.host)
- Notas rápidas e painel
